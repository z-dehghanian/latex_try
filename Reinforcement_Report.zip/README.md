# HomeworkTemplate
## Introduction
Let's free our homework and proejct definitions. check it out [here](main.pdf).
